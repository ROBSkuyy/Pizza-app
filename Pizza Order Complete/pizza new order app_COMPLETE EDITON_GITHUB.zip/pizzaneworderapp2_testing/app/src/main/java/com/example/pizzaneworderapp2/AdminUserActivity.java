// AdminUserActivity.java

package com.example.pizzaneworderapp2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdminUserActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private DatabaseHelper databaseHelper;
    private List<User> userList;
    private ImageButton backButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_user);

        databaseHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewUsers);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(view -> onBackPressed());

        loadUsers();

        userAdapter = new UserAdapter(userList, this, new UserAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(User user, int position) {
                deleteUser(user, position);
            }
        });
        recyclerView.setAdapter(userAdapter);
    }

    private void loadUsers() {
        userList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query("users", null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex("id");
                int nameIndex = cursor.getColumnIndex("name");
                int emailIndex = cursor.getColumnIndex("email");
                int passwordIndex = cursor.getColumnIndex("password");

                if (idIndex != -1 && nameIndex != -1 && emailIndex != -1 && passwordIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String name = cursor.getString(nameIndex);
                    String email = cursor.getString(emailIndex);
                    String password = cursor.getString(passwordIndex);

                    User user = new User(id, name, email, password);
                    userList.add(user);
                }
            }
            cursor.close();
        }
    }

    private void deleteUser(User user, int position) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int deletedRows = db.delete("users", "id=?", new String[]{String.valueOf(user.getId())});

        if (deletedRows > 0) {
            Toast.makeText(this, "User deleted", Toast.LENGTH_SHORT).show();
            userList.remove(position);
            userAdapter.notifyItemRemoved(position);
        } else {
            Toast.makeText(this, "Failed to delete user", Toast.LENGTH_SHORT).show();
        }
    }
}
