package com.example.pizzaneworderapp2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class OrderDetailsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewOrderDetails;
    private OrderDetailsAdapter orderDetailsAdapter;
    private List<Pizza> orderItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        recyclerViewOrderDetails = findViewById(R.id.recyclerViewOrderDetails);
        recyclerViewOrderDetails.setLayoutManager(new LinearLayoutManager(this));

        String orderItemsJson = getIntent().getStringExtra("ORDER_ITEMS");
        Gson gson = new Gson();
        Type listType = new TypeToken<List<Pizza>>() {}.getType();
        orderItems = gson.fromJson(orderItemsJson, listType);

        orderDetailsAdapter = new OrderDetailsAdapter(orderItems);
        recyclerViewOrderDetails.setAdapter(orderDetailsAdapter);
    }
}
