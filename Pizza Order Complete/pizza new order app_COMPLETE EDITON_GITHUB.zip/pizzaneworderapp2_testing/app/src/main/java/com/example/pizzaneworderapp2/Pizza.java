package com.example.pizzaneworderapp2;

import android.net.Uri;
import java.io.Serializable;

public class Pizza implements Serializable {
    private int id;
    private String namaPizza;
    private String deskripsi;
    private String harga;
    private Uri foto;
    private int quantity;
    private String userEmail; // Tambahkan ini

    public Pizza(int id, String namaPizza, String deskripsi, String harga, Uri foto) {
        this.id = id;
        this.namaPizza = namaPizza;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.foto = foto;
        this.quantity = 0; // Initial quantity is 0
    }

    public int getId() {
        return id;
    }

    public String getNamaPizza() {
        return namaPizza;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getHarga() {
        return harga;
    }

    public Uri getFoto() {
        return foto;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNamaPizza(String namaPizza) {
        this.namaPizza = namaPizza;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public void setFoto(Uri foto) {
        this.foto = foto;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public void incrementQuantity() {
        this.quantity++;
    }

    public void decrementQuantity() {
        if (this.quantity > 0) {
            this.quantity--;
        }
    }
}
