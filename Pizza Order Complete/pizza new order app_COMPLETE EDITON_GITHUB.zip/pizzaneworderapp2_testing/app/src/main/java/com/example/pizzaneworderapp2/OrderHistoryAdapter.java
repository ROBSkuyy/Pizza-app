package com.example.pizzaneworderapp2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.OrderHistoryViewHolder> {

    private List<Order> orderHistory;
    private Context context;

    public OrderHistoryAdapter(List<Order> orderHistory, Context context) {
        this.orderHistory = orderHistory;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderHistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_history, parent, false);
        return new OrderHistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderHistoryViewHolder holder, int position) {
        Order order = orderHistory.get(position);
        holder.orderDate.setText(order.getOrderDate());
        holder.orderTotal.setText("Rp " + order.getOrderTotal());

        holder.deleteButton.setOnClickListener(v -> {
            DatabaseHelper dbHelper = new DatabaseHelper(context);
            boolean isDeleted = dbHelper.deleteOrderHistory(order.getOrderId());
            if (isDeleted) {
                orderHistory.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, orderHistory.size());
                Toast.makeText(context, "Order deleted successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Failed to delete order", Toast.LENGTH_SHORT).show();
            }
        });

        holder.detailsButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, OrderDetailsActivity.class);
            intent.putExtra("ORDER_ITEMS", order.getOrderItems());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return orderHistory.size();
    }

    public static class OrderHistoryViewHolder extends RecyclerView.ViewHolder {

        TextView orderDate, orderTotal;
        Button deleteButton, detailsButton;

        public OrderHistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            orderDate = itemView.findViewById(R.id.orderDate);
            orderTotal = itemView.findViewById(R.id.orderTotal);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            detailsButton = itemView.findViewById(R.id.detailsButton);
        }
    }
}
