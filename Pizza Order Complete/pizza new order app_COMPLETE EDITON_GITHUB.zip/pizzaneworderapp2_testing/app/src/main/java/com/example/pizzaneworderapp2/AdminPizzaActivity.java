package com.example.pizzaneworderapp2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class AdminPizzaActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_EDIT_PIZZA = 1;

    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;
    private List<Pizza> pizzaList;
    private PizzaAdapter adapter;
    private ImageButton tambahButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_pizza);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);
        pizzaList = new ArrayList<>();

        tambahButton = findViewById(R.id.tambah);
        tambahButton.setOnClickListener(v -> {
            Intent intent = new Intent(AdminPizzaActivity.this, TambahPizzaAdminActivity.class);
            startActivityForResult(intent, REQUEST_CODE_EDIT_PIZZA);
        });

        backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(view -> onBackPressed());

        loadPizzas();
    }

    private void loadPizzas() {
        pizzaList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM pizzas", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String namaPizza = cursor.getString(cursor.getColumnIndexOrThrow("namaPizza"));
                String deskripsi = cursor.getString(cursor.getColumnIndexOrThrow("deskripsi"));
                String harga = cursor.getString(cursor.getColumnIndexOrThrow("harga"));
                String foto = cursor.getString(cursor.getColumnIndexOrThrow("foto"));

                Pizza pizza = new Pizza(id, namaPizza, deskripsi, harga, Uri.parse(foto));
                pizzaList.add(pizza);
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter = new PizzaAdapter(pizzaList, this, true);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_EDIT_PIZZA && resultCode == RESULT_OK) {
            loadPizzas();
        }
    }

    public void deletePizza(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int result = db.delete("pizzas", "id=?", new String[]{String.valueOf(id)});
        if (result != -1) {
            Toast.makeText(this, "Pizza berhasil dihapus", Toast.LENGTH_SHORT).show();
            loadPizzas();
        } else {
            Toast.makeText(this, "Gagal menghapus pizza", Toast.LENGTH_SHORT).show();
        }
    }

    public void editPizza(Pizza pizza) {
        Intent intent = new Intent(AdminPizzaActivity.this, TambahPizzaAdminActivity.class);
        intent.putExtra("id", pizza.getId());
        intent.putExtra("namaPizza", pizza.getNamaPizza());
        intent.putExtra("deskripsi", pizza.getDeskripsi());
        intent.putExtra("harga", pizza.getHarga());
        intent.putExtra("foto", pizza.getFoto().toString());
        startActivityForResult(intent, REQUEST_CODE_EDIT_PIZZA);
    }
}
