package com.example.pizzaneworderapp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderDetailsAdapter extends RecyclerView.Adapter<OrderDetailsAdapter.OrderDetailsViewHolder> {

    private List<Pizza> orderItems;

    public OrderDetailsAdapter(List<Pizza> orderItems) {
        this.orderItems = orderItems;
    }

    @NonNull
    @Override
    public OrderDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_detail, parent, false);
        return new OrderDetailsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderDetailsViewHolder holder, int position) {
        Pizza pizza = orderItems.get(position);
        holder.pizzaName.setText(pizza.getNamaPizza());
        holder.pizzaDescription.setText(pizza.getDeskripsi());
        holder.pizzaPrice.setText("Rp " + pizza.getHarga());
        holder.pizzaQuantity.setText("Quantity: " + pizza.getQuantity());
    }

    @Override
    public int getItemCount() {
        return orderItems.size();
    }

    public static class OrderDetailsViewHolder extends RecyclerView.ViewHolder {

        TextView pizzaName, pizzaDescription, pizzaPrice, pizzaQuantity;

        public OrderDetailsViewHolder(@NonNull View itemView) {
            super(itemView);
            pizzaName = itemView.findViewById(R.id.pizzaName);
            pizzaDescription = itemView.findViewById(R.id.pizzaDescription);
            pizzaPrice = itemView.findViewById(R.id.pizzaPrice);
            pizzaQuantity = itemView.findViewById(R.id.pizzaQuantity);
        }
    }
}
