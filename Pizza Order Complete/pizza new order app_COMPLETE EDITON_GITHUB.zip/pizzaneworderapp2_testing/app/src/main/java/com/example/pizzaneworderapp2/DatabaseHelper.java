package com.example.pizzaneworderapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 4; // Update version to 4

    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_PIZZAS = "pizzas";
    private static final String COLUMN_PIZZA_ID = "id";
    private static final String COLUMN_PIZZA_NAME = "namaPizza";
    private static final String COLUMN_DESCRIPTION = "deskripsi";
    private static final String COLUMN_PRICE = "harga";
    private static final String COLUMN_PHOTO = "foto";

    private static final String TABLE_CART = "cart";
    private static final String COLUMN_CART_ID = "id";
    private static final String COLUMN_CART_USER_EMAIL = "user_email";
    private static final String COLUMN_CART_PIZZA_ID = "pizza_id";
    private static final String COLUMN_CART_QUANTITY = "quantity";

    private static final String TABLE_ORDER_HISTORY = "order_history";
    private static final String COLUMN_ORDER_ID = "order_id";
    private static final String COLUMN_ORDER_DATE = "order_date";
    private static final String COLUMN_ORDER_USER_EMAIL = "order_user_email";
    private static final String COLUMN_ORDER_TOTAL = "order_total";
    private static final String COLUMN_ORDER_ITEMS = "order_items";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DatabaseHelper", "Creating user table");
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_EMAIL + " TEXT, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        Log.d("DatabaseHelper", "Creating pizza table");
        String createPizzaTable = "CREATE TABLE " + TABLE_PIZZAS + " (" +
                COLUMN_PIZZA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PIZZA_NAME + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_PRICE + " TEXT, " +
                COLUMN_PHOTO + " TEXT)";
        db.execSQL(createPizzaTable);

        Log.d("DatabaseHelper", "Creating cart table");
        String createCartTable = "CREATE TABLE " + TABLE_CART + " (" +
                COLUMN_CART_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CART_USER_EMAIL + " TEXT, " +
                COLUMN_CART_PIZZA_ID + " INTEGER, " +
                COLUMN_CART_QUANTITY + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_CART_PIZZA_ID + ") REFERENCES " + TABLE_PIZZAS + "(" + COLUMN_PIZZA_ID + "), " +
                "FOREIGN KEY(" + COLUMN_CART_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_EMAIL + "))";
        db.execSQL(createCartTable);

        Log.d("DatabaseHelper", "Creating order history table");
        String createOrderHistoryTable = "CREATE TABLE " + TABLE_ORDER_HISTORY + " (" +
                COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ORDER_DATE + " TEXT, " +
                COLUMN_ORDER_USER_EMAIL + " TEXT, " +
                COLUMN_ORDER_TOTAL + " REAL, " +
                COLUMN_ORDER_ITEMS + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_ORDER_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_EMAIL + "))";
        db.execSQL(createOrderHistoryTable);

        // Insert admin user if not exists
        if (!checkEmail("admin@gmail.com", db)) {
            Log.d("DatabaseHelper", "Inserting admin user");
            insertData("admin", "admin@gmail.com", "123", db);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("DatabaseHelper", "Upgrading database from version " + oldVersion + " to " + newVersion);
        if (oldVersion < 2) {
            Log.d("DatabaseHelper", "Creating pizza table in upgrade");
            String createPizzaTable = "CREATE TABLE " + TABLE_PIZZAS + " (" +
                    COLUMN_PIZZA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_PIZZA_NAME + " TEXT, " +
                    COLUMN_DESCRIPTION + " TEXT, " +
                    COLUMN_PRICE + " TEXT, " +
                    COLUMN_PHOTO + " TEXT)";
            db.execSQL(createPizzaTable);
        }

        if (oldVersion < 3) {
            Log.d("DatabaseHelper", "Creating cart table in upgrade");
            String createCartTable = "CREATE TABLE " + TABLE_CART + " (" +
                    COLUMN_CART_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_CART_USER_EMAIL + " TEXT, " +
                    COLUMN_CART_PIZZA_ID + " INTEGER, " +
                    COLUMN_CART_QUANTITY + " INTEGER)";
            db.execSQL(createCartTable);
        }

        if (oldVersion < 4) {
            Log.d("DatabaseHelper", "Creating order history table in upgrade");
            String createOrderHistoryTable = "CREATE TABLE " + TABLE_ORDER_HISTORY + " (" +
                    COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ORDER_DATE + " TEXT, " +
                    COLUMN_ORDER_USER_EMAIL + " TEXT, " +
                    COLUMN_ORDER_TOTAL + " REAL, " +
                    COLUMN_ORDER_ITEMS + " TEXT, " +
                    "FOREIGN KEY(" + COLUMN_ORDER_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_EMAIL + "))";
            db.execSQL(createOrderHistoryTable);
        }
    }

    public boolean insertData(String name, String email, String password, SQLiteDatabase db) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_EMAIL, email);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public boolean insertData(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        return insertData(name, email, password, db);
    }

    public boolean checkEmail(String email, SQLiteDatabase db) {
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return checkEmail(email, db);
    }

    public boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean addUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_EMAIL, email);
        contentValues.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public boolean checkUserExists(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public int deletePizza(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_PIZZAS, COLUMN_PIZZA_ID + "=?", new String[]{String.valueOf(id)});
    }

    public boolean insertPizza(String name, String description, String price, String photo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_PIZZA_NAME, name);
        contentValues.put(COLUMN_DESCRIPTION, description);
        contentValues.put(COLUMN_PRICE, price);
        contentValues.put(COLUMN_PHOTO, photo);
        long result = db.insert(TABLE_PIZZAS, null, contentValues);
        return result != -1;
    }

    public boolean addCartItem(String userEmail, int pizzaId, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_CART_USER_EMAIL, userEmail);
        contentValues.put(COLUMN_CART_PIZZA_ID, pizzaId);
        contentValues.put(COLUMN_CART_QUANTITY, quantity);

        String whereClause = COLUMN_CART_USER_EMAIL + "=? AND " + COLUMN_CART_PIZZA_ID + "=?";
        String[] whereArgs = {userEmail, String.valueOf(pizzaId)};

        int rows = db.update(TABLE_CART, contentValues, whereClause, whereArgs);
        if (rows == 0) {
            long result = db.insert(TABLE_CART, null, contentValues);
            return result != -1;
        }
        return true;
    }

    public Cursor getCartItems(String userEmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CART + " WHERE " + COLUMN_CART_USER_EMAIL + "=?";
        return db.rawQuery(query, new String[]{userEmail});
    }

    public void clearCart(String userEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, COLUMN_CART_USER_EMAIL + "=?", new String[]{userEmail});
    }

    public boolean removeCartItem(String userEmail, int pizzaId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_CART, COLUMN_CART_USER_EMAIL + "=? AND " + COLUMN_CART_PIZZA_ID + "=?", new String[]{userEmail, String.valueOf(pizzaId)}) > 0;
    }

    public boolean updateUser(String name, String oldEmail, String newEmail, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_EMAIL, newEmail);
        contentValues.put(COLUMN_PASSWORD, password);

        int result = db.update(TABLE_USERS, contentValues, COLUMN_EMAIL + "=?", new String[]{oldEmail});
        return result > 0; // returns true if at least one row is updated, false otherwise
    }

    public boolean insertOrderHistory(String orderDate, String userEmail, double orderTotal, String orderItems) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_ORDER_DATE, orderDate);
        contentValues.put(COLUMN_ORDER_USER_EMAIL, userEmail);
        contentValues.put(COLUMN_ORDER_TOTAL, orderTotal);
        contentValues.put(COLUMN_ORDER_ITEMS, orderItems);
        long result = db.insert(TABLE_ORDER_HISTORY, null, contentValues);
        return result != -1;
    }

    public Cursor getOrderHistory(String userEmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_ORDER_HISTORY + " WHERE " + COLUMN_ORDER_USER_EMAIL + "=?";
        return db.rawQuery(query, new String[]{userEmail});
    }

    public boolean deleteOrderHistory(int orderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ORDER_HISTORY, COLUMN_ORDER_ID + "=?", new String[]{String.valueOf(orderId)}) > 0;
    }

    // Getters for table and column names
    public static String getTableUsers() {
        return TABLE_USERS;
    }

    public static String getColumnName() {
        return COLUMN_NAME;
    }

    public static String getColumnEmail() {
        return COLUMN_EMAIL;
    }

    public static String getColumnPassword() {
        return COLUMN_PASSWORD;
    }

    public static String getTablePizzas() {
        return TABLE_PIZZAS;
    }

    public static String getColumnPizzaId() {
        return COLUMN_PIZZA_ID;
    }

    public static String getColumnPizzaName() {
        return COLUMN_PIZZA_NAME;
    }

    public static String getColumnDescription() {
        return COLUMN_DESCRIPTION;
    }

    public static String getColumnPrice() {
        return COLUMN_PRICE;
    }

    public static String getColumnPhoto() {
        return COLUMN_PHOTO;
    }

    public static String getTableCart() {
        return TABLE_CART;
    }

    public static String getColumnCartUserEmail() {
        return COLUMN_CART_USER_EMAIL;
    }

    public static String getColumnCartPizzaId() {
        return COLUMN_CART_PIZZA_ID;
    }

    public static String getColumnCartQuantity() {
        return COLUMN_CART_QUANTITY;
    }

    public static String getTableOrderHistory() {
        return TABLE_ORDER_HISTORY;
    }

    public static String getColumnOrderId() {
        return COLUMN_ORDER_ID;
    }

    public static String getColumnOrderDate() {
        return COLUMN_ORDER_DATE;
    }

    public static String getColumnOrderUserEmail() {
        return COLUMN_ORDER_USER_EMAIL;
    }

    public static String getColumnOrderTotal() {
        return COLUMN_ORDER_TOTAL;
    }

    public static String getColumnOrderItems() {
        return COLUMN_ORDER_ITEMS;
    }
}
