package com.example.pizzaneworderapp2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class PizzaAdapter extends RecyclerView.Adapter<PizzaAdapter.PizzaViewHolder> {

    private List<Pizza> pizzaList;
    private Context context;
    private DatabaseHelper dbHelper;
    private String userEmail;
    private boolean isAdmin;

    // Constructor for user with email
    public PizzaAdapter(List<Pizza> pizzaList, Context context, String userEmail) {
        this.pizzaList = pizzaList;
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.userEmail = userEmail;
        this.isAdmin = false;
    }

    // Constructor for admin
    public PizzaAdapter(List<Pizza> pizzaList, Context context, boolean isAdmin) {
        this.pizzaList = pizzaList;
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.isAdmin = isAdmin;
        this.userEmail = null; // No user email required for admin
    }

    @NonNull
    @Override
    public PizzaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(isAdmin ? R.layout.item_pizza_admin : R.layout.item_pizza_user, parent, false);
        return new PizzaViewHolder(view, isAdmin);
    }

    @Override
    public void onBindViewHolder(@NonNull PizzaViewHolder holder, int position) {
        Pizza pizza = pizzaList.get(position);
        holder.namaPizza.setText(pizza.getNamaPizza());
        holder.deskripsi.setText(pizza.getDeskripsi());
        holder.harga.setText("Rp. " + pizza.getHarga());

        String fotoUrl = pizza.getFoto().toString();
        Glide.with(context).load(fotoUrl).into(holder.foto);

        if (!isAdmin) {
            // Muat kuantitas dari tabel cart
            int quantity = getCartQuantity(userEmail, pizza.getId());
            pizza.setQuantity(quantity);
            holder.itemCount.setText("Item: " + pizza.getQuantity());

            holder.plusButton.setOnClickListener(v -> {
                pizza.incrementQuantity();
                holder.itemCount.setText("Item: " + pizza.getQuantity());
                Toast.makeText(context, "Pizza berhasil ditambah", Toast.LENGTH_SHORT).show();

                // Tambahkan item ke tabel cart
                dbHelper.addCartItem(userEmail, pizza.getId(), pizza.getQuantity());
            });

            holder.minusButton.setOnClickListener(v -> {
                if (pizza.getQuantity() > 0) {
                    pizza.decrementQuantity();
                    holder.itemCount.setText("Item: " + pizza.getQuantity());
                    Toast.makeText(context, "Pizza berhasil dihapus", Toast.LENGTH_SHORT).show();

                    // Perbarui item di tabel cart
                    if (pizza.getQuantity() == 0) {
                        dbHelper.removeCartItem(userEmail, pizza.getId());
                    } else {
                        dbHelper.addCartItem(userEmail, pizza.getId(), pizza.getQuantity());
                    }
                }
            });
        } else {
            // Admin actions (e.g., edit, delete) can be handled here
            holder.editButton.setOnClickListener(v -> {
                if (context instanceof AdminPizzaActivity) {
                    ((AdminPizzaActivity) context).editPizza(pizza);
                }
            });

            holder.deleteButton.setOnClickListener(v -> {
                if (context instanceof AdminPizzaActivity) {
                    ((AdminPizzaActivity) context).deletePizza(pizza.getId());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return pizzaList.size();
    }

    private int getCartQuantity(String userEmail, int pizzaId) {
        int quantity = 0;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT quantity FROM " + DatabaseHelper.getTableCart() + " WHERE " + DatabaseHelper.getColumnCartUserEmail() + "=? AND " + DatabaseHelper.getColumnCartPizzaId() + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{userEmail, String.valueOf(pizzaId)});
        if (cursor != null && cursor.moveToFirst()) {
            quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnCartQuantity()));
            cursor.close();
        }
        return quantity;
    }

    public static class PizzaViewHolder extends RecyclerView.ViewHolder {

        TextView namaPizza, deskripsi, harga, itemCount;
        ImageView foto;
        ImageButton plusButton, minusButton, editButton, deleteButton;

        public PizzaViewHolder(@NonNull View itemView, boolean isAdmin) {
            super(itemView);
            namaPizza = itemView.findViewById(R.id.nama_pizza);
            deskripsi = itemView.findViewById(R.id.deskripsi);
            harga = itemView.findViewById(R.id.harga);
            foto = itemView.findViewById(R.id.profileImage);
            itemCount = itemView.findViewById(R.id.item_count);

            if (!isAdmin) {
                plusButton = itemView.findViewById(R.id.btnPlus);
                minusButton = itemView.findViewById(R.id.btnMinus);
            } else {
                editButton = itemView.findViewById(R.id.btnEdit);
                deleteButton = itemView.findViewById(R.id.btnDelete);
            }
        }
    }
}
