package com.example.pizzaneworderapp2;

public class Order {
    private int orderId;
    private String orderDate;
    private String userEmail;
    private double orderTotal;
    private String orderItems;

    public Order(int orderId, String orderDate, String userEmail, double orderTotal, String orderItems) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.userEmail = userEmail;
        this.orderTotal = orderTotal;
        this.orderItems = orderItems;
    }

    public int getOrderId() {
        return orderId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public String getOrderItems() {
        return orderItems;
    }
}
