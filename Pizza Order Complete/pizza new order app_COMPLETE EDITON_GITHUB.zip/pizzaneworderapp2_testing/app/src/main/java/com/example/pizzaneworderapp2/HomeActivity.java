package com.example.pizzaneworderapp2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;
    private List<Pizza> pizzaList;
    private PizzaAdapter adapter;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);
        pizzaList = new ArrayList<>();

        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userEmail = prefs.getString("user_email", "user@example.com");

        Button buttonLogout = findViewById(R.id.button_logout);
        buttonLogout.setOnClickListener(v -> {
            // Implementasi logout
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove("user_email");
            editor.apply();

            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    // Sudah di halaman home
                    return true;
                } else if (itemId == R.id.nav_cart) {
                    Intent cartIntent = new Intent(HomeActivity.this, CartActivity.class);
                    startActivity(cartIntent);
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                    profileIntent.putExtra("EMAIL", userEmail);
                    startActivity(profileIntent);
                    return true;
                }
                return false;
            }
        });

        loadPizzas();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPizzas();
    }

    private void loadPizzas() {
        pizzaList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM pizzas", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPizzaId()));
                String namaPizza = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPizzaName()));
                String deskripsi = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnDescription()));
                String harga = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPrice()));
                String foto = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPhoto()));

                Pizza pizza = new Pizza(id, namaPizza, deskripsi, harga, Uri.parse(foto));
                // Set kuantitas pizza dari tabel cart
                int quantity = getCartQuantity(userEmail, id);
                pizza.setQuantity(quantity);
                pizzaList.add(pizza);
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter = new PizzaAdapter(pizzaList, this, userEmail); // Pass user email
        recyclerView.setAdapter(adapter);
    }

    private int getCartQuantity(String userEmail, int pizzaId) {
        int quantity = 0;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT quantity FROM " + DatabaseHelper.getTableCart() + " WHERE " + DatabaseHelper.getColumnCartUserEmail() + "=? AND " + DatabaseHelper.getColumnCartPizzaId() + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{userEmail, String.valueOf(pizzaId)});
        if (cursor != null && cursor.moveToFirst()) {
            quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnCartQuantity()));
            cursor.close();
        }
        return quantity;
    }
}
