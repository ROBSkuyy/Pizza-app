package com.example.pizzaneworderapp2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<Pizza> cartItems;
    private Context context;

    public CartAdapter(List<Pizza> cartItems, Context context) {
        this.cartItems = cartItems;
        this.context = context;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        Pizza pizza = cartItems.get(position);
        holder.namaPizza.setText(pizza.getNamaPizza());
        holder.harga.setText("Rp " + formatHarga(Double.parseDouble(pizza.getHarga())));
        holder.quantity.setText(String.valueOf(pizza.getQuantity()));

        String fotoUrl = pizza.getFoto().toString();
        Glide.with(context).load(fotoUrl).into(holder.foto);

        holder.plusButton.setOnClickListener(v -> {
            pizza.incrementQuantity();
            holder.quantity.setText(String.valueOf(pizza.getQuantity()));
            DatabaseHelper dbHelper = new DatabaseHelper(context);
            dbHelper.addCartItem(pizza.getUserEmail(), pizza.getId(), pizza.getQuantity());
            ((CartActivity) context).updateTotal();
        });

        holder.minusButton.setOnClickListener(v -> {
            if (pizza.getQuantity() > 0) {
                pizza.decrementQuantity();
                holder.quantity.setText(String.valueOf(pizza.getQuantity()));
                DatabaseHelper dbHelper = new DatabaseHelper(context);

                if (pizza.getQuantity() == 0) {
                    dbHelper.removeCartItem(pizza.getUserEmail(), pizza.getId());
                    cartItems.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, cartItems.size());
                } else {
                    dbHelper.addCartItem(pizza.getUserEmail(), pizza.getId(), pizza.getQuantity());
                }

                ((CartActivity) context).updateTotal();
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    private String formatHarga(double harga) {
        NumberFormat format = NumberFormat.getInstance(new Locale("id", "ID"));
        format.setGroupingUsed(true);
        format.setMaximumFractionDigits(0); // Menghilangkan angka di belakang koma
        return format.format(harga);
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {

        TextView namaPizza, harga, quantity;
        ImageView foto;
        ImageButton plusButton, minusButton;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            namaPizza = itemView.findViewById(R.id.nama_pizza);
            harga = itemView.findViewById(R.id.harga);
            quantity = itemView.findViewById(R.id.quantity);
            foto = itemView.findViewById(R.id.profileImage);
            plusButton = itemView.findViewById(R.id.btnPlus);
            minusButton = itemView.findViewById(R.id.btnMinus);
        }
    }
}
