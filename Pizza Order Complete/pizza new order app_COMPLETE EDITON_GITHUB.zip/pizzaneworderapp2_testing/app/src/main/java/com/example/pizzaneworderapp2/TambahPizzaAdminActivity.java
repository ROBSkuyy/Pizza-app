package com.example.pizzaneworderapp2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class TambahPizzaAdminActivity extends AppCompatActivity {

    private EditText etNamaPizza, etDeskripsi, etHarga, etFoto;
    private Button btnSimpan;
    private DatabaseHelper dbHelper;
    private int pizzaId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tambah_pizza_admin);

        etNamaPizza = findViewById(R.id.etNamaPizza);
        etDeskripsi = findViewById(R.id.etDeskripsi);
        etHarga = findViewById(R.id.etHarga);
        etFoto = findViewById(R.id.etFoto);
        btnSimpan = findViewById(R.id.btnSimpan);
        dbHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            pizzaId = intent.getIntExtra("id", -1);
            etNamaPizza.setText(intent.getStringExtra("namaPizza"));
            etDeskripsi.setText(intent.getStringExtra("deskripsi"));
            etHarga.setText(intent.getStringExtra("harga"));
            etFoto.setText(intent.getStringExtra("foto"));
        }

        btnSimpan.setOnClickListener(v -> {
            String namaPizza = etNamaPizza.getText().toString().trim();
            String deskripsi = etDeskripsi.getText().toString().trim();
            String harga = etHarga.getText().toString().trim();
            String foto = etFoto.getText().toString().trim();

            if (!namaPizza.isEmpty() && !deskripsi.isEmpty() && !harga.isEmpty() && !foto.isEmpty()) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues contentValues = new ContentValues();
                contentValues.put("namaPizza", namaPizza);
                contentValues.put("deskripsi", deskripsi);
                contentValues.put("harga", harga);
                contentValues.put("foto", foto);

                long result;
                if (pizzaId != -1) {
                    // Update pizza yang ada
                    result = db.update("pizzas", contentValues, "id=?", new String[]{String.valueOf(pizzaId)});
                } else {
                    // Tambahkan pizza baru
                    result = db.insert("pizzas", null, contentValues);
                }

                if (result != -1) {
                    Toast.makeText(TambahPizzaAdminActivity.this, "Pizza berhasil disimpan", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(TambahPizzaAdminActivity.this, "Gagal menyimpan pizza", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(TambahPizzaAdminActivity.this, "Mohon lengkapi semua field", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
