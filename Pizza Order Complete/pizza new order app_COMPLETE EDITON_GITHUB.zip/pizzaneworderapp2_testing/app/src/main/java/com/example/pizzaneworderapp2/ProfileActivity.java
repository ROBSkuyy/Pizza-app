package com.example.pizzaneworderapp2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText etNama, etEmail, etPassword, etConfirm;
    private Button btnUpdate;
    private DatabaseHelper dbHelper;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        etNama = findViewById(R.id.etNama);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirm = findViewById(R.id.etConfirm);
        btnUpdate = findViewById(R.id.btnUpdate);
        dbHelper = new DatabaseHelper(this);

        // Get user email from intent
        userEmail = getIntent().getStringExtra("EMAIL");
        loadUserData(userEmail);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserProfile();
            }
        });

        TextView tvOrderHistory = findViewById(R.id.tvOrderHistory);
        tvOrderHistory.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, OrderHistoryActivity.class);
            intent.putExtra("EMAIL", userEmail);
            startActivity(intent);
        });
    }

    private void loadUserData(String email) {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(
                "SELECT * FROM " + DatabaseHelper.getTableUsers() + " WHERE " + DatabaseHelper.getColumnEmail() + "=?",
                new String[]{email});
        if (cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex(DatabaseHelper.getColumnName());
            int emailIndex = cursor.getColumnIndex(DatabaseHelper.getColumnEmail());
            int passwordIndex = cursor.getColumnIndex(DatabaseHelper.getColumnPassword());
            if (nameIndex != -1) {
                etNama.setText(cursor.getString(nameIndex));
            }
            if (emailIndex != -1) {
                etEmail.setText(cursor.getString(emailIndex));
            }
            if (passwordIndex != -1) {
                etPassword.setText(cursor.getString(passwordIndex));
            }
        }
        cursor.close();
    }

    private void updateUserProfile() {
        String name = etNama.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirm = etConfirm.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirm)) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirm)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isUpdated = dbHelper.updateUser(name, userEmail, email, password);
        if (isUpdated) {
            Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
            // Update the old email to the new email
            userEmail = email;
        } else {
            Toast.makeText(this, "Profile update failed", Toast.LENGTH_SHORT).show();
        }
    }
}
