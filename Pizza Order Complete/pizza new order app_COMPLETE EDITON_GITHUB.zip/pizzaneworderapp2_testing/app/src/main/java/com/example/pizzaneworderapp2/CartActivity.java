package com.example.pizzaneworderapp2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import com.google.gson.Gson;

public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerViewCart;
    private CartAdapter cartAdapter;
    private List<Pizza> cartItems;
    private TextView totalAmount;
    private DatabaseHelper databaseHelper;
    private String userEmail;
    private EditText deliveryAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        databaseHelper = new DatabaseHelper(this);

        recyclerViewCart = findViewById(R.id.recyclerViewCart);
        recyclerViewCart.setLayoutManager(new LinearLayoutManager(this));

        totalAmount = findViewById(R.id.totalAmount);
        deliveryAddress = findViewById(R.id.address);

        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userEmail = prefs.getString("user_email", "user@example.com");

        cartItems = getCartItemsFromDatabase();
        cartAdapter = new CartAdapter(cartItems, this);
        recyclerViewCart.setAdapter(cartAdapter);

        // Load saved delivery address
        String savedAddress = prefs.getString("delivery_address", "");
        deliveryAddress.setText(savedAddress);

        // Save delivery address on change
        deliveryAddress.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("delivery_address", deliveryAddress.getText().toString());
                editor.apply();
            }
        });

        updateTotal();

        Button placeOrderButton = findViewById(R.id.placeOrderButton);
        placeOrderButton.setOnClickListener(v -> {
            placeOrder();
        });

        // Add click listener for backButton
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            finish(); // Finish the current activity to go back to the previous activity
        });
    }

    private List<Pizza> getCartItemsFromDatabase() {
        List<Pizza> items = new ArrayList<>();
        Cursor cursor = databaseHelper.getCartItems(userEmail);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int pizzaId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnCartPizzaId()));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnCartQuantity()));
                Pizza pizza = getPizzaById(pizzaId);
                if (pizza != null) {
                    pizza.setQuantity(quantity);
                    pizza.setUserEmail(userEmail); // Set user email
                    items.add(pizza);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return items;
    }

    private Pizza getPizzaById(int pizzaId) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String query = "SELECT * FROM " + DatabaseHelper.getTablePizzas() + " WHERE " + DatabaseHelper.getColumnPizzaId() + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(pizzaId)});
        if (cursor != null && cursor.moveToFirst()) {
            String namaPizza = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPizzaName()));
            String deskripsi = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnDescription()));
            String harga = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPrice()));
            String foto = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnPhoto()));
            cursor.close();
            return new Pizza(pizzaId, namaPizza, deskripsi, harga, Uri.parse(foto));
        }
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }

    public void updateTotal() {
        double total = 0;
        for (Pizza pizza : cartItems) {
            total += Double.parseDouble(pizza.getHarga()) * pizza.getQuantity();
        }
        DecimalFormat format = new DecimalFormat("#,###");
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        format.setDecimalFormatSymbols(symbols);
        totalAmount.setText("Rp " + format.format(total));
    }

    private void placeOrder() {
        String orderDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        double total = getTotalAmount(); // Implement this method to calculate the total order amount
        String orderItems = new Gson().toJson(cartItems); // Convert cart items to JSON string

        boolean isInserted = databaseHelper.insertOrderHistory(orderDate, userEmail, total, orderItems);
        if (isInserted) {
            Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show();
            databaseHelper.clearCart(userEmail);
            cartItems.clear();
            cartAdapter.notifyDataSetChanged();
            updateTotal();
        } else {
            Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
        }
    }

    private double getTotalAmount() {
        double total = 0;
        for (Pizza pizza : cartItems) {
            total += Double.parseDouble(pizza.getHarga()) * pizza.getQuantity();
        }
        return total;
    }
}
