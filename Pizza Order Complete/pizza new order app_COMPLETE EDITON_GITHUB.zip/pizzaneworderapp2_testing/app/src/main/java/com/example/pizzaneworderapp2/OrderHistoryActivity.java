package com.example.pizzaneworderapp2;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewOrderHistory;
    private OrderHistoryAdapter orderHistoryAdapter;
    private DatabaseHelper databaseHelper;
    private List<Order> orderHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        recyclerViewOrderHistory = findViewById(R.id.recyclerViewOrderHistory);
        recyclerViewOrderHistory.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);

        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String userEmail = prefs.getString("user_email", "user@example.com");

        orderHistory = getOrderHistoryFromDatabase(userEmail);
        orderHistoryAdapter = new OrderHistoryAdapter(orderHistory, this);
        recyclerViewOrderHistory.setAdapter(orderHistoryAdapter);
    }

    private List<Order> getOrderHistoryFromDatabase(String userEmail) {
        List<Order> orders = new ArrayList<>();
        Cursor cursor = databaseHelper.getOrderHistory(userEmail);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int orderId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnOrderId()));
                String orderDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnOrderDate()));
                double orderTotal = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnOrderTotal()));
                String orderItems = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.getColumnOrderItems()));
                orders.add(new Order(orderId, orderDate, userEmail, orderTotal, orderItems));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return orders;
    }
}
