package com.example.pizzaneworderapp2;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private static Cart instance;
    private List<Pizza> cartItems;

    private Cart() {
        cartItems = new ArrayList<>();
    }

    public static synchronized Cart getInstance() {
        if (instance == null) {
            instance = new Cart();
        }
        return instance;
    }

    public void addItem(Pizza pizza) {
        cartItems.add(pizza);
    }

    public void removeItem(Pizza pizza) {
        cartItems.remove(pizza);
    }

    public List<Pizza> getCartItems() {
        return cartItems;
    }

    public double getTotal() {
        double total = 0;
        for (Pizza pizza : cartItems) {
            total += Double.parseDouble(pizza.getHarga()) * pizza.getQuantity();
        }
        return total;
    }
}
