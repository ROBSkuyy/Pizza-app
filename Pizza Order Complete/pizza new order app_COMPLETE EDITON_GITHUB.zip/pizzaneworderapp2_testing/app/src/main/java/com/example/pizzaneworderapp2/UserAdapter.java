// UserAdapter.java

package com.example.pizzaneworderapp2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<User> userList;
    private Context context;
    private OnDeleteClickListener onDeleteClickListener;

    public UserAdapter(List<User> userList, Context context, OnDeleteClickListener onDeleteClickListener) {
        this.userList = userList;
        this.context = context;
        this.onDeleteClickListener = onDeleteClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_admin, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user = userList.get(position);
        holder.namaTextView.setText(user.getName());
        holder.emailTextView.setText(user.getEmail());
        holder.passwordTextView.setText(user.getPassword());

        holder.deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentPosition = holder.getAdapterPosition();
                if (currentPosition != RecyclerView.NO_POSITION) {
                    onDeleteClickListener.onDeleteClick(userList.get(currentPosition), currentPosition);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView namaTextView, emailTextView, passwordTextView;
        public ImageView deleteImageView;

        public ViewHolder(View itemView) {
            super(itemView);
            namaTextView = itemView.findViewById(R.id.Nama);
            emailTextView = itemView.findViewById(R.id.email);
            passwordTextView = itemView.findViewById(R.id.password);
            deleteImageView = itemView.findViewById(R.id.btnDelete);
        }
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(User user, int position);
    }
}
